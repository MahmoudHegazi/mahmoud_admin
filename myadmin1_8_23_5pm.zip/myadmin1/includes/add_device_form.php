<?php
// Include config file
require_once "db.php";
 
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
   }
   
   
// Define variables and initialize with empty values
$stag = $manufacture = $purchased_date = $sup_id = $price = $history = $status = $image = $model = $type = "";





// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
     
        $stag = test_input($_POST['tag']);
		$manufacture = test_input($_POST['man']);
		$purchased_date = test_input($_POST['pdate']);
		$sup_id = test_input($_POST['supid']);
		$price = test_input($_POST['price']);
		$history = test_input($_POST['history']);
		$status = test_input($_POST['status']);
		$image = test_input($_POST['image']);
		$model = test_input($_POST['model']);
		$type = test_input($_POST['type']);
	
        // Prepare an insert statement
        $sql = "INSERT INTO users (service_tag, manufacture, purchased_date, supplier_id, price,
		history, status, images, model, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssissssss", $param_stag, $param_man, $param_date, $param_supid, $param_price, $param_history, $param_status, $param_image, $param_model, $param_typ);
            
            // Set parameters
            $param_stag = $stag;
            $param_man = $manufacture;
			$param_date = $purchased_date;
			$param_supid = $sup_id;
			$param_price = $price;
			$param_history = $history;
			$param_status = $status;
			$param_image = $image;
			$param_model = $model;
			$param_typ = $type;
			
			$param_name = $uname;
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: /");
			  
            } else{
                echo 'user: ' . $param_username . '<br>';
				echo 'user_err: ' . $username_err. '<br>';
                echo 'pass err :' . $password_err. '<br>';
                echo 'pass : ' . $password. '<br>';
				
				//echo "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }

    
    // Close connection
    mysqli_close($con);
}
	

	


?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">Add New Device</div>
				<div class="panel-body">
				
				
        <form  action="add_device_form.php" method="post" role="form">
		  <fieldset>	  
            <div class="form-group">
                <label>service_tag</label>
                <input type="text" name="tag" class="form-control" value="<?php echo $stag; ?>">
                <span class="help-block"><?php //echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>manufacture</label>
                <input type="text" name="man" class="form-control" value="<?php echo $manufacture; ?>">
                <span class="help-block"><?php //echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>purchased_date</label>
                <input type="date" name="pdate" class="form-control" value="<?php echo $purchased_date; ?>">
                <span class="help-block"><?php //echo $confirm_password_err; ?></span>
            </div>

		
            <div class="form-group">
                <label>supplier_id</label>
                <input type="number" name="supid" class="form-control" value="<?php echo $sup_id; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>
			
            <div class="form-group">
                <label>price</label>
                <input type="text" name="price" class="form-control" value="<?php echo $price; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>

            <div class="form-group">
                <label>history</label>
                <input type="text" name="history" class="form-control" value="<?php echo $history; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>

            <div class="form-group">
                <label>status</label>
                <input type="text" name="status" class="form-control" value="<?php echo $status; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>			


            <div class="form-group">
                <label>image</label>
                <input type="text" name="image" class="form-control" value="<?php echo $image; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>

            <div class="form-group">
                <label>model</label>
                <input type="text" name="model" class="form-control" value="<?php echo $model; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>	
			
            <div class="form-group">
                <label>Type</label>
                <input type="text" name="type" class="form-control" value="<?php echo $type; ?>">
                <span class="help-block"><?php  //echo $name_err; ?></span>
            </div>	
			
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a href="/"><input type="button" class="btn btn-default" value="Cancel"></a>
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
	      </fieldset>
        </form>
    </div>    
				</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
</body>
</html>